﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            char[] delimiterChars = { ' ', ',', '.', ':', '\t' }; 
            
            List<string> lstCommandArgs = new List<string>(); 
            //ADDING NUMBERS INPUT FROM COMMAND LINE INTO LIST
            for (int command = 0; command < args.Length; command++)
            {
                if(args[command].Split(delimiterChars).Length > 1)
                {                    
                    string [] localarray = args[command].Split(delimiterChars);

                    for (int i = 0; i < localarray.Length; i++)
                    {
                        lstCommandArgs.Add(localarray[i]);
                    }                   
                }
                else
                {
                    lstCommandArgs.Add(args[command]);
                }
                
            }            
            string operation = lstCommandArgs.First();            
            if (operation != null) {
                if (operation.Equals("Sum"))
                { Sum(lstCommandArgs); }
            }
            else
            {
                Console.WriteLine("Operation invalid: "+operation);
            }
        }
        //Sum method creates an array of integer input and pass it to another method performAddition which is responsible to 
        //take an input parameter as numeric array and responds back with addition
        private static void Sum(List<string> lstCommandArgs)
        {
            int num;

            double[] numbers = new double[lstCommandArgs.Count];
            string[] numbersLocal = new string[lstCommandArgs.Count];

            for (int i = 0; i < lstCommandArgs.Count; i++)
            {
                if (Int32.TryParse(lstCommandArgs[i], out num))
                {
                    numbers[i] = num;
                }
            }

            double total = performAddition(numbers);
            Console.WriteLine("Total Added : " + total);
        }

        #region Commented Code 
        /*
        private static void Sum(string[] commandArgs)
        {
            int num;            
            double[] numbers = new double[commandArgs.Length];
            string[] numbersLocal = new string[commandArgs.Length];
            for (int i = 0; i < commandArgs.Length; i++)
            {
                if (Int32.TryParse(commandArgs[i], out num))
                    {
                        numbers[i] = num;
                    }                
            }
           double total =  performAddition(numbers);            
           Console.WriteLine("Total Addition : "+ total);
        }
        */
    #endregion

        private static double performAddition(double[] numbers)
        {
            double totalAdded = 0;
            for (int i = 0; i < numbers.Length; i++)
            {
                totalAdded = totalAdded + numbers[i];
            }
            return totalAdded;
        }
    }
}
