﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            char[] delimiterChars = { '\n','\\',';', ' ', ',', '.', ':', '\t' };
            //string[] args1 = { "add 2\\n3,4" };
            //args = args1;
            List<string> lstCommandArgs = new List<string>(); 
            //ADDING NUMBERS INPUT FROM COMMAND LINE INTO LIST
            for (int command = 0; command < args.Length; command++)
            {
                if(args[command].Split(delimiterChars).Length > 1)
                {                    
                    string [] localarray = args[command].Split(delimiterChars);

                    for (int i = 0; i < localarray.Length; i++)
                    {
                        lstCommandArgs.Add(localarray[i]);
                    }                   
                }
                else
                {
                    lstCommandArgs.Add(args[command]);
                }
                
            }            
            string operation = lstCommandArgs.First();            
            if (operation != null) {
                if (operation.Equals("Add") || operation.Equals("add") || operation.Equals("Sum") || operation.Equals("sum"))
                { Sum(lstCommandArgs); }
            }
            else
            {
                Console.WriteLine("Operation invalid: "+operation);
            }
        }
        //Sum method creates an array of integer input and pass it to another method performAddition which is responsible to 
        //take an input parameter as numeric array and responds back with addition
        private static void Sum(List<string> lstCommandArgs)
        {
            int num; bool flag = false;

            double[] numbers = new double[lstCommandArgs.Count];
            string[] numbersLocal = new string[lstCommandArgs.Count];
            List<double> negativeNumbers = new List<double>();

            for (int i = 0; i < lstCommandArgs.Count; i++)
            {
                if (Int32.TryParse(lstCommandArgs[i], out num))
                {
                    if(num > 0 && num<1000)
                    {
                        numbers[i] = num;
                    }
                    else if(num > 1000)
                    {
                        //do nothing, do not add the number just escape it
                    }
                    else
                    {
                        
                        negativeNumbers.Add(num);
                        flag = true;
                        //break;
                    }
                }
               
            }
            if (!flag)
            {
                double total = performAddition(numbers);
                Console.WriteLine("Total Added : " + total);
            }
            else
            {

                //var numberCollection = from numcoll in negativeNumbers select numcoll;
                foreach (var item in negativeNumbers)
                {
                    Console.WriteLine("Negative numbers not allowed : " +item);
                }
                
            }

        }

        #region Commented Code 
        /*
        private static void Sum(string[] commandArgs)
        {
            int num;            
            double[] numbers = new double[commandArgs.Length];
            string[] numbersLocal = new string[commandArgs.Length];
            for (int i = 0; i < commandArgs.Length; i++)
            {
                if (Int32.TryParse(commandArgs[i], out num))
                    {
                        numbers[i] = num;
                    }                
            }
           double total =  performAddition(numbers);            
           Console.WriteLine("Total Addition : "+ total);
        }
        */
    #endregion

        private static double performAddition(double[] numbers)
        {
            double totalAdded = 0;
            for (int i = 0; i < numbers.Length; i++)
            {
                totalAdded = totalAdded + numbers[i];
            }
            return totalAdded;
        }
    }
}
